package com.example.taskmate;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {

    ArrayList<Task> taskList;
    private OnTaskLongClickListener longClickListener;
    private OnTaskClickListener clickListener;

    // Constructor
    public TaskAdapter(
            ArrayList<Task> taskList,
            OnTaskLongClickListener longClickListener,
            OnTaskClickListener clickListener
    ) {
        this.taskList = taskList;
        this.longClickListener = longClickListener;
        this.clickListener = clickListener;
    }

    // Interfaces
    public interface OnTaskLongClickListener {
        void onTaskLongClick(int position);
    }

    public interface OnTaskClickListener {
        void onTaskClick(int position);
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.task_row, parent, false);
        return new TaskViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        Task task = taskList.get(position);

        holder.txtTaskTitle.setText(task.getTitle());
        holder.checkTask.setChecked(task.isCompleted());

        holder.checkTask.setOnCheckedChangeListener((buttonView, isChecked) -> {
            task.setCompleted(isChecked);
        });

        // ✅ SINGLE TAP → EDIT
        holder.itemView.setOnClickListener(v -> {
            if (clickListener != null) {
                clickListener.onTaskClick(position);
            }
        });

        // ✅ LONG PRESS → DELETE
        holder.itemView.setOnLongClickListener(v -> {
            if (longClickListener != null) {
                longClickListener.onTaskLongClick(position);
            }
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return taskList.size();
    }

    static class TaskViewHolder extends RecyclerView.ViewHolder {

        TextView txtTaskTitle;
        CheckBox checkTask;

        public TaskViewHolder(@NonNull View itemView) {
            super(itemView);
            txtTaskTitle = itemView.findViewById(R.id.txtTaskTitle);
            checkTask = itemView.findViewById(R.id.checkTask);
        }
    }
}