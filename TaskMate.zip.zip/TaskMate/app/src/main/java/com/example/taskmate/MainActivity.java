package com.example.taskmate;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    Button btnAddTask;
    ArrayList<Task> taskList;
    TaskAdapter adapter;

    SharedPreferences sharedPreferences;
    Gson gson;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        btnAddTask = findViewById(R.id.btnAddTask);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        sharedPreferences = getSharedPreferences("TaskPrefs", MODE_PRIVATE);
        gson = new Gson();

        loadTasks();

        adapter = new TaskAdapter(

                taskList,

                // 🔴 LONG PRESS → DELETE
                position -> {
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Delete Task")
                            .setMessage("Are you sure you want to delete this task?")
                            .setPositiveButton("Yes", (dialog, which) -> {
                                taskList.remove(position);
                                adapter.notifyItemRemoved(position);
                                saveTasks();
                            })
                            .setNegativeButton("No", null)
                            .show();
                },

                // 🟢 SINGLE TAP → EDIT
                this::onTaskClick
        );

        recyclerView.setAdapter(adapter);

        btnAddTask.setOnClickListener(v -> {
            taskList.add(new Task("New Task"));
            adapter.notifyItemInserted(taskList.size() - 1);
            saveTasks();
        });
    }

    // ✏️ EDIT TASK
    private void onTaskClick(int position) {
        Task task = taskList.get(position);

        final EditText input = new EditText(this);
        input.setText(task.getTitle());

        new AlertDialog.Builder(this)
                .setTitle("Edit Task")
                .setView(input)
                .setPositiveButton("Save", (dialog, which) -> {
                    task.setTitle(input.getText().toString());
                    adapter.notifyItemChanged(position);
                    saveTasks();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void saveTasks() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        String json = gson.toJson(taskList);
        editor.putString("task_list", json);
        editor.apply();
    }

    private void loadTasks() {
        String json = sharedPreferences.getString("task_list", null);
        Type type = new TypeToken<ArrayList<Task>>() {}.getType();

        if (json != null) {
            taskList = gson.fromJson(json, type);
        } else {
            taskList = new ArrayList<>();
            taskList.add(new Task("Buy groceries"));
            taskList.add(new Task("Study Android"));
            taskList.add(new Task("Finish internship task"));
        }
    }
}
